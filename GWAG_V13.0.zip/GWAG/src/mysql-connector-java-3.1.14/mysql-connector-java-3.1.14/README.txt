MySQL Connector/J @MYSQL_CJ_VERSION@ (formerly MM.MySQL)
MySQL AB's JDBC Driver for MySQL
Copyright (c) 2003 MySQL AB

CONTENTS

* License
* Documentation Location


LICENSE

MySQL Connector/J is licensed under the GPL or a commercial license
from MySQL AB. 

If you have licensed this product under the GPL, please see the COPYING
file for more information. 

There are special exceptions to the terms and conditions of the GPL 
as it is applied to this software. View the full text of the 
exception in file EXCEPTIONS-CONNECTOR-J in the directory of this 
software distribution.

If you have licensed this product under a commercial license from
MySQL AB, please see the file "MySQLEULA.txt" that comes with this 
distribution for the terms of the license.

If you need non-GPL licenses for commercial distribution please contact 
me <mark@mysql.com> or <sales@mysql.com>.


DOCUMENTATION LOCATION
 
The documentation formerly contained in this file has moved into the 
'doc' directory, where it is available in HTML, PDF and plaintext
forms.

You may also find the latest copy of the documentation on the MySQL
website at http://dev.mysql.com/doc/refman/5.0/en/connector-j.html

--
This software is OSI Certified Open Source Software.
OSI Certified is a certification mark of the Open Source Initiative.



/**
 * __A class to try our game so far.
 * @author __Naisila Puka___
 * @version __30/04/2017__
 */
import java.awt.*;
import java.io.*;
import javax.swing.*;
public class Try
{
  public static void main(String[] args) throws IOException, InterruptedException
  {
    LaunchFrame frame = new LaunchFrame();
    frame.setVisible(true);
  }
}